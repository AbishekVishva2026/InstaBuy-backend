package com.example.userservice.controller;

import com.example.userservice.Exception.NotFoundException;
import com.example.userservice.dto.AddressDTO;
import com.example.userservice.dto.AuthUser;
import com.example.userservice.dto.ProfileDTO;
import com.example.userservice.model.Address;
import com.example.userservice.model.Profile;
import com.example.userservice.model.User;
import com.example.userservice.repository.UserRepository;
import com.example.userservice.security.JwtUtil;
import com.example.userservice.service.AddressService;
import com.example.userservice.service.ProfileService;
import com.example.userservice.service.UserService;
import io.jsonwebtoken.Claims;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

    private final ProfileService profileService;
    private final AddressService addressService;
    private final UserService userService;

    public ProfileController(ProfileService profileService,AddressService addressService,UserService userService){
        this.profileService=profileService;
        this.addressService=addressService;
        this.userService=userService;
    }

    @PostMapping
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<?> createProfile(
            @RequestBody @Valid ProfileDTO profileDto,
            Authentication authentication) {
        try {
            org.springframework.security.core.userdetails.User authUser = (org.springframework.security.core.userdetails.User) authentication.getPrincipal();
            User user=userService.getUserByUserName(authUser.getUsername());
            Profile profile=new Profile();
            profile.setUser(user);
            profile.setFirstName(profileDto.getFirstName());
            if(profileDto.getLastName()!=null){
                profile.setLastName(profileDto.getLastName());
            }
            profile.setPhone(profileDto.getPhone());
            Profile createdProfile= profileService.createProfile(user.getId(), profile);
            return ResponseEntity.ok(createdProfile);
        }catch (AccessDeniedException e){
            return ResponseEntity.status(403).body(e.getMessage());
        }catch (IllegalStateException e){
            return ResponseEntity.status(404).body(e.getMessage());
        }catch (Exception e){
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @GetMapping
    @PreAuthorize("hasRole('CUSTOMER')")
    public ResponseEntity<?> getProfile(Authentication authentication) {
        try {
            org.springframework.security.core.userdetails.User authUser = (org.springframework.security.core.userdetails.User) authentication.getPrincipal();
            User user=userService.getUserByUserName(authUser.getUsername());
            Profile profile = profileService.getProfile(user.getId());
            return ResponseEntity.ok(profile);
        }catch (NotFoundException e){
            return ResponseEntity.status(404).body(e.getMessage());
        }catch (Exception e){
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }


    @PostMapping("/addresses")
    public ResponseEntity<?> addAddress(
            @RequestBody @Valid AddressDTO addressDTO,
            Authentication authentication
    ) {
        try {
            org.springframework.security.core.userdetails.User authUser = (org.springframework.security.core.userdetails.User) authentication.getPrincipal();
            User user=userService.getUserByUserName(authUser.getUsername());
            Address address=new Address();
            address.setFullName(addressDTO.getFullName());
            address.setPhone(addressDTO.getPhone());
            address.setStreetAddress(addressDTO.getStreetAddress());
            address.setCity(addressDTO.getCity());
            address.setState(addressDTO.getState());
            address.setCountry(addressDTO.getCountry());
            address.setPostalCode(addressDTO.getPostalCode());
            address.setAddressType(addressDTO.getAddressType());
            Address savedAddress = addressService.addAddress(user.getId(), address);
            return ResponseEntity.ok(savedAddress);
        }catch (NotFoundException e){
            return ResponseEntity.status(404).body(e.getMessage());
        }catch (Exception e){
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }


    @PutMapping("/delivery-address/{addressId}")
    public ResponseEntity<?> setDelivery(
            @PathVariable Long addressId,
            Authentication authentication) {
        try {
            org.springframework.security.core.userdetails.User authUser = (org.springframework.security.core.userdetails.User) authentication.getPrincipal();
            User user=userService.getUserByUserName(authUser.getUsername());
            Profile profile=profileService.setDeliveryAddress(user.getId(), addressId);
            return ResponseEntity.ok(profile);
        }catch (NotFoundException e){
            return ResponseEntity.status(404).body(e.getMessage());
        }catch (Exception e){
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

    @PutMapping("/billing-address/{addressId}")
    public ResponseEntity<?> setBilling(
            @PathVariable Long addressId,
            Authentication authentication) {
        try {
            org.springframework.security.core.userdetails.User authUser = (org.springframework.security.core.userdetails.User) authentication.getPrincipal();
            User user=userService.getUserByUserName(authUser.getUsername());
            Profile profile=profileService.setBillingAddress(user.getId(), addressId);
            return ResponseEntity.ok(profile);
        }catch (NotFoundException e){
            return ResponseEntity.status(404).body(e.getMessage());
        }catch (Exception e){
            return ResponseEntity.status(500).body(e.getMessage());
        }
    }

}