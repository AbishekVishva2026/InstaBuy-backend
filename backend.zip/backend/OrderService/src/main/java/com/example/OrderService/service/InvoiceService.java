package com.example.OrderService.service;

import com.example.OrderService.dto.VendorProfileResponseDTO;
import com.example.OrderService.model.OrderItem;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Map;

@Service
public class InvoiceService {

    private final UserService vendorProfileService;
    private final InvoicePdfGenerator invoicePdfGenerator;
    private final MailService mailService;

    public InvoiceService(UserService vendorProfileService, InvoicePdfGenerator invoicePdfGenerator, MailService mailService){
        this.vendorProfileService=vendorProfileService;
        this.invoicePdfGenerator=invoicePdfGenerator;
        this.mailService=mailService;
    }

    public void sendInvoice(String useremail,Map<Long, ArrayList<OrderItem>> orderReport) {

        for(Map.Entry<Long, ArrayList<OrderItem>> entry: orderReport.entrySet()){
            Long vendorId = entry.getKey();
            VendorProfileResponseDTO vendorDetails=vendorProfileService.getVendorProfile(vendorId);
            ArrayList<OrderItem> items = entry.getValue();
            try {
                String filePath=invoicePdfGenerator.generateInvoicePdf(vendorDetails, items);
                mailService.sendInvoicePath(useremail,filePath);
            }catch (Exception e){
                mailService.sendErrorMessage(useremail,e.getMessage());
            }
        }
    }
}
