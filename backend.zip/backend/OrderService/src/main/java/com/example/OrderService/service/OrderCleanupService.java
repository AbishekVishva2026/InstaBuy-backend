package com.example.OrderService.service;


import com.example.OrderService.model.OrderStatus;
import com.example.OrderService.repository.OrderRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;

@Slf4j
@Service
@RequiredArgsConstructor
public class OrderCleanupService {

    private final OrderRepository orderRepository;

    // 🔥 10 minutes TTL
    private static final Duration ORDER_TTL = Duration.ofMinutes(10);

    // Run once when app starts
    @EventListener(ApplicationReadyEvent.class)
    @Transactional
    public void initCleanupOnce() {
        cleanupExpiredOrders();
    }

    // Run every 5 minutes (recommended instead of 1 hour)
    @Scheduled(fixedRate = 300_000) // 5 min
    @Transactional
    public void scheduledCleanup() {
        cleanupExpiredOrders();
    }

    public void cleanupExpiredOrders() {
        Instant threshold = Instant.now().minus(ORDER_TTL);

        int deleted = orderRepository
                .deleteByStatusAndCreatedAtBefore(
                        OrderStatus.PAYMENT_INITIATED,
                        threshold
                );
        deleted+=orderRepository
                .deleteByStatusAndCreatedAtBefore(
                        OrderStatus.CREATED,
                        threshold
                );

        log.info("Order cleanup: deleted {} PAYMENT_INITIATED orders older than {}", deleted, threshold);
    }
}