package com.example.OrderService.service;

import com.example.OrderService.dto.PaymentEvent;
import com.example.OrderService.exception.NotFoundException;
import com.example.OrderService.model.OrderStatus;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

@Component
public class PaymentEventConsumer {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final OrderService orderService;
    private final OrderEventProducer orderEventProducer;

    public PaymentEventConsumer(OrderService orderService,OrderEventProducer orderEventProducer){
        this.orderService=orderService;
        this.orderEventProducer=orderEventProducer;
    }

    @JmsListener(destination = "payment.events")
    public void consume(String message) {

        try {
            System.out.println("Received JSON: " + message);

            PaymentEvent event =
                    objectMapper.readValue(message, PaymentEvent.class);

            handleEvent(event);

        } catch (Exception e) {
            System.err.println("Failed to process message");
            e.printStackTrace();
        }
    }

    private void handleEvent(PaymentEvent event)  {
        try {
            switch (event.getEventType()) {

                case "PAYMENT_INITIALIZED":
                    orderService.setOrderStatus(event.getOrderId(), OrderStatus.PAYMENT_INITIATED);
                    break;

                case "PAYMENT_CONFIRMED":
                    orderService.setOrderStatus(event.getOrderId(), OrderStatus.CONFIRMED);
                    orderEventProducer.sendConfirmOrder(event.getOrderId());
                    break;

                case "PAYMENT_FAILED":
                    orderService.setOrderStatus(event.getOrderId(), OrderStatus.FAILED);
                    orderEventProducer.sendFailureOrder(event.getOrderId());
                    break;

                default:
                    System.out.println("Unknown event type");
            }
        }catch (NotFoundException e){
            System.out.println(e.getMessage());
        }
    }
}