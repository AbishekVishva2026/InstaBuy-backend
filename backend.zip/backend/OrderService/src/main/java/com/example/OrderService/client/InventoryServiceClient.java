package com.example.OrderService.client;

import com.example.OrderService.config.InventoryFeignConfig;
import com.example.OrderService.dto.UpdateQuantityRequestDTO;
import com.example.OrderService.dto.VendorProductResponse;
import jakarta.validation.Valid;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;


@FeignClient(
        name = "INVENTORY-SERVICE",
        configuration = InventoryFeignConfig.class,
        url = "http://127.0.0.1:8080"
)
public interface InventoryServiceClient {

    @PatchMapping(
            value = "/api/inventory/product/reserve/{id}",
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public VendorProductResponse updateReserveQuantityById(
            @PathVariable("id") Long id,
            @RequestBody UpdateQuantityRequestDTO request,
            @RequestHeader("Authorization") String authToken
    );


    @GetMapping("/api/inventory/{id}")
    public VendorProductResponse getVendorProduct(@PathVariable Long id,@RequestHeader("Authorization") String authToken);

    @PatchMapping(
            value = "/api/inventory/product/{id}",
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public VendorProductResponse updateQuantityById(@PathVariable Long id, @Valid @RequestBody UpdateQuantityRequestDTO request,@RequestHeader("Authorization") String authToken);

    @PatchMapping(
            value = "/api/inventory/product/reserve/{id}",
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public VendorProductResponse releaseReserveQuantityById(@PathVariable Long id, @Valid @RequestBody UpdateQuantityRequestDTO request, @RequestHeader("Authorization") String authToken);

    @PatchMapping(
            value = "/api/inventory/product/release/{id}",
            consumes = MediaType.APPLICATION_JSON_VALUE
    )
    public VendorProductResponse releaseProductByReserveQuantity(@PathVariable Long id, @Valid @RequestBody UpdateQuantityRequestDTO request, @RequestHeader("Authorization") String authToken);

}
