package com.example.OrderService.repository;

import com.example.OrderService.model.Order;
import com.example.OrderService.model.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order,Long> {
    List<Order> findByUserId(Long userId);
    List<Order> findByUserIdAndStatus(Long userId, OrderStatus status);
    @Transactional
    @Modifying
    int deleteByStatusAndCreatedAtBefore(OrderStatus status, Instant time);
}
