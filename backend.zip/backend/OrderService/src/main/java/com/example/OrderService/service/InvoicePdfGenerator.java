package com.example.OrderService.service;

import com.example.OrderService.model.OrderItem;
import com.example.OrderService.dto.VendorProfileResponseDTO;
import com.itextpdf.kernel.pdf.*;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.*;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

@Service
public class InvoicePdfGenerator {


    private static final String BASE_DIR = "C:/Users/abishekvishva.a/Documents/invoices/";


    public String generateInvoicePdf(
            VendorProfileResponseDTO vendor,
            List<OrderItem> items) throws IOException {

        ByteArrayOutputStream out = new ByteArrayOutputStream();

        PdfWriter writer = new PdfWriter(out);
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        document.add(new Paragraph("INVOICE")
                .setBold()
                .setFontSize(18));

        document.add(new Paragraph("Company: " + vendor.getCompanyName()));
        document.add(new Paragraph("Email: " + vendor.getEmail()));
        document.add(new Paragraph("Phone: " + vendor.getPhone()));
        document.add(new Paragraph(
                vendor.getStreetAddress() + ", " +
                        vendor.getCity() + ", " +
                        vendor.getState() + ", " +
                        vendor.getCountry() + " - " +
                        vendor.getPostalCode()
        ));

        document.add(new Paragraph(" "));

        // 🔹 Table
        Table table = new Table(5);
        table.addHeaderCell("Product ID");
        table.addHeaderCell("Quantity");
        table.addHeaderCell("Price");
        table.addHeaderCell("Discount");
        table.addHeaderCell("Final Price");

        double totalAmount = 0;

        for (OrderItem item : items) {
            table.addCell(item.getProductId());
            table.addCell(String.valueOf(item.getQuantity()));
            table.addCell(String.valueOf(item.getPrice()));
            table.addCell(item.getDiscount() + "%");
            table.addCell(String.valueOf(item.getFinalPrice()));

            totalAmount += item.getFinalPrice();
        }

        document.add(table);

        document.add(new Paragraph("\nTotal Amount: ₹" + totalAmount)
                .setBold());

        document.close();


        String vendorDir = BASE_DIR + vendor.getCompanyName().replace(" ", "_");
        Files.createDirectories(Paths.get(vendorDir));

        String filePath = vendorDir + "/invoice_" + System.currentTimeMillis() + ".pdf";
        Files.write(Paths.get(filePath), out.toByteArray());

        return filePath;
    }
}