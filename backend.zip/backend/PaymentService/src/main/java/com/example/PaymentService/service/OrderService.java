package com.example.PaymentService.service;

import com.example.PaymentService.client.OrderServiceClient;
import com.example.PaymentService.dto.OrderRequestDTO;
import com.example.PaymentService.dto.OrderResponse;
import jakarta.validation.Valid;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

@Service
public class OrderService {

    private final OrderServiceClient orderServiceClient;

    public OrderService(OrderServiceClient orderServiceClient){
        this.orderServiceClient=orderServiceClient;
    }

    public OrderResponse reserveOrder(Long id,Long userId, String authToken){
        return orderServiceClient.reserveOrder(id,new OrderRequestDTO(userId),authToken);
    }

    public OrderResponse placeOrder(Long id,Long userId, String authToken){

        return orderServiceClient.placeOrder(id,new OrderRequestDTO(userId),authToken);
    }

    public OrderResponse placeOrderFailed(Long id,Long userId, String authToken){
        return orderServiceClient.placeOrderFailed(id,new OrderRequestDTO(userId),authToken);
    }

    public OrderResponse getOrderById(Long id, Long userId, String authToken){
        return orderServiceClient.getOrderById(id,new OrderRequestDTO(userId),authToken);
    }
}
