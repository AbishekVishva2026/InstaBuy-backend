package com.example.OrderService.repository;

import com.example.OrderService.dto.SalesReportDTO;
import com.example.OrderService.model.SalesEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;

@Repository
public interface SalesEntryRepository extends JpaRepository<SalesEntry,Long> {
    List<SalesEntry> findByVendorId(Long vendorId);


    List<SalesEntry> findByVendorIdAndCreatedAtBetween(
            Long vendorId,
            Instant start,
            Instant end
    );


    @Query("""
        SELECT new com.example.OrderService.dto.SalesReportDTO(
            COUNT(DISTINCT s.orderId),
            SUM(s.quantity),
            SUM(s.discountAmount),
            SUM(s.finalPrice*s.quantity)
        )
        FROM SalesEntry s
        WHERE s.vendorId = :vendorId
        AND s.createdAt BETWEEN :startDate AND :endDate
    """)
    SalesReportDTO getVendorSalesReportByDays(
            @Param("vendorId") Long vendorId,
            @Param("startDate") Instant startDate,
            @Param("endDate") Instant endDate
    );

    @Query("""
        SELECT new com.example.OrderService.dto.SalesReportDTO(
            COUNT(DISTINCT s.orderId),
            SUM(s.quantity),
            SUM(s.discountAmount),
            SUM(s.finalPrice*s.quantity)
        )
        FROM SalesEntry s
        WHERE s.vendorId = :vendorId
    """)
    SalesReportDTO getVendorSalesReport(@Param("vendorId") Long vendorId);

}

